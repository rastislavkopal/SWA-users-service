define({
  "name": "users-service",
  "version": "1.2.2",
  "description": "School project for Software Architectures",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2022-06-28T20:48:24.667Z",
    "url": "https://apidocjs.com",
    "version": "0.28.1"
  }
});
